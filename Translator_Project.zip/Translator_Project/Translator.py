import tkinter as tk
from tkinter import ttk,messagebox
import speech_recognition as sr
import pyttsx3
from googletrans import Translator,LANGUAGES
from gtts import gTTS
from playsound import playsound
from flask import Flask, render_template, request, jsonify

import os

app = Flask(__name__)
recognizer = sr.Recognizer()
translator = Translator()
engine = pyttsx3.init()

lang_dict = {lang.title():code for code, lang in LANGUAGES.items()}
lang_names = sorted(lang_dict.keys())
@app.route('/')
def index():
    return render_template('index.html',languages = lang_names)

@app.route('/translate',methods = ['POST'])
def translate():
    data = request.json
    src_lang = lang_dict.get(data.get('sourceLang'))
    dest_lang = lang_dict.get(data.get('targetLang'))
    text = data.get('text')

    if not text or not src_lang or not dest_lang:
        return jsonify({'error': 'Invalid input'}), 400

    translated = translator.translate(text, src=src_lang, dest=dest_lang)
    return jsonify({'translatedText': translated.text})


if __name__ == '__main__':
    app.run(debug=True)
    # src_lang_name = src_lang_var.get()
    # dest_lang_name = dest_lang_var.get()
    #
    #
    # if not src_lang_name and not dest_lang_name:
    #     messagebox.showerror("Error","Please select the both the source and destination")
    #     return
    #
    # src_lang = lang_dict[src_lang_name]
    # dest_lang = lang_dict[dest_lang_name]
    #
    # with sr.Microphone() as source:
    #     try:
    #         status_label.config(text=f"Listening...{src_lang_name}")
    #         root.update()
    #         audio = recognizer.listen(source, timeout=5)
    #
    #         status_label.config(text="Recognizing...")
    #         root.update()
    #         original_text = recognizer.recognize_google(audio,language = src_lang)
    #         input.set(original_text)
    #
    #         status_label.config(text=f"Translating...{dest_lang_name}")
    #         root.update()
    #         translated = translator.translate(original_text, src=src_lang, dest=dest_lang)
    #         translated_text = translated.text
    #         output.set(translated_text)
    #
    #
    #     except Exception as e:
    #         print(e)

# root = tk.Tk()
# root.title("Voice Translator")
# #root.geometry("500 * 300")
# root.configure(bg = "white")
#
# src_lang_var = tk.StringVar()
# dest_lang_var = tk.StringVar()
# input = tk.StringVar()
# output = tk.StringVar()
#
# tk.Label(root,text="Speak In : ",font=("Arial",20),bg="white").pack(pady = 10)
# src_lang_menu  = ttk.Combobox(root,textvariable=src_lang_var,values=lang_names,state="readonly",width=30)
# src_lang_menu.set(("English"))
# src_lang_menu.pack(pady = 5)
#
# tk.Label(root,text="Translate to : ",font=("Arial",20),bg="white").pack(pady = 10)
# dest_lang_menu  = ttk.Combobox(root,textvariable=dest_lang_var,values=lang_names,state="readonly",width=30)
# dest_lang_menu.set(("Hindi"))
# dest_lang_menu.pack(pady = 5)
#
# tk.Entry(root, textvariable=input, font=("Arial", 12), width=50).pack(pady=10)
# tk.Entry(root, textvariable=output, font=("Arial", 12), width=50).pack(pady=10)
#
# tk.Button(root,command=translate_speak,font=("Arial",15),bg="lightblue").pack(pady = 10)
# status_label = tk.Label(root, text="", font=("Arial", 10), bg="white", fg="green")
# status_label.pack()
#
# root.mainloop()